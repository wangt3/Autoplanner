Autoplanner: An autoplanner to plan out tasks that require a long time to perform, like lab assignments
or studying that may take multiple hours/days/weeks. If you can estimate a timeframe for how long
you think the project will take, this autoplanner will help automatically chop up and assign times for
you to work on your large assigments. (Its nice to estimate a time, then multiply it by 1.5 for any
project in general, as we are horribly bad at estimating things)

HOW 2 USE

1.) DOWNLOAD YOUR CALENDAR FROM GOOGLE CALENDAR OR WHEREVER
	a.) GOOGLE CALENDAR
	b.) CLICK ON GEAR THEN ON "SETTINGS" TAB
	c.) CLICK ON "IMPORT & EXPORT"
	d.) CLICK ON "EXPORT"
	e.) DRAG FILES TO SAME FOLDER AS THE AUTOPLANNER
2.) RUN THE AUTOPLANNER BY DOUBLE CLICKING THE AUTOPLANNER.PY FILE
3.) CLICK ON "TASK ENTRY"
	a.) ENTER TASK DETAILS. TASK LENGTH IS IN HOURS
	b.) CLICK ON SUBMIT
	c.) THEN SELECT A TASK END DATE, BY CLICKING AROUND IN THE CALENDAR
5.) CLICK ON TASK PRIORITY
	a.) THEN SELECT A PRIORITY (KINDA DOESNT DO ANYTHING RIGHT NOW)
	addendum: CAN ONLY SELECT 10 TASKS, DO NOT ADD MORE THAN 10.
6.) CLICK ON TASK CALENDAR
	a.) THIS WILL OPEN A PROMPT IN THE COMMAND PROMPT
	b.) ENTER THE NAME OF YOUR ICS IF THERE ARE MULTIPLE. THEN PRESS ENTER
	c.) PRESS "OK" ON THE DONE PAGE
		i.) AN INVISIBLE BLENDER WILL DO SOME BLENDING, PLEASE WAIT 5 SECONDS OR SO 
7.) YOU NOW HAVE TWO NEW .CSV FILES, "TIMESHEET.CSV" and "CALSHEET.CSV"
	a.) TAKE IN "CALSHEET.CSV" AND IMPORT IT INTO GOOGLE CALENDAR, SAME AREA AS THE EXPORT
8.) ITS DONE, CLOSE THE PROGRAM BY CLICKING THE X ON THE TOP RIGHT CORNER